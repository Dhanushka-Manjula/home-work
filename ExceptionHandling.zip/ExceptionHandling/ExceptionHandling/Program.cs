﻿using System;
namespace ExceptionHandling
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter a number between 0 and 255: ");
                double firstNumber = Double.Parse(Console.ReadLine());

                Console.Write("Enter another number between 0 and 255: ");
                double secondNumber = Double.Parse(Console.ReadLine());

                if ( 0 <= firstNumber && 255 >= firstNumber && 0 <= secondNumber && 255 >= secondNumber   )
                {
                    double result = firstNumber / secondNumber;
                    Console.WriteLine("{0} divided by {1} is {2}", firstNumber, secondNumber, result);
                }
                else
                {
                    Console.WriteLine("Input numbers should between 0 - 255 ");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("FormatException: Input string was not in a correct format.");
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Attempted divide by zero.");
            }
        }
    }
}

