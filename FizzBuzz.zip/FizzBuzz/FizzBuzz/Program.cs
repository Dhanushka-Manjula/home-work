﻿using System;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            FindFizzBuzz(100);
        }

        // Find all Fizzbuzzes between 1 to the given number.
        static void FindFizzBuzz(int count)
        {
            string output = "";

            for (int number = 1; number <= count; number++)
            {
                if (number % 3 == 0 && number % 5 == 0)
                {
                    output += "FizzBuzz, ";
                }
                else if (number % 3 == 0)
                {
                    output += "Fizz, ";
                }
                else if (number % 5 == 0)
                {
                    output += "Buzz, ";
                }
                else
                {
                    output += number + ", ";
                }

            }
           
            Console.WriteLine(output.Remove(output.Length - 2));
        }
    }
}

