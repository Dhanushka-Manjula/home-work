﻿using System;
namespace PrimeFactors
{
    public class Factors
    {

        public string PrimeFactors(int number)
        {
            if ( number < 1)
            {
                return "Can not find the Prime factors for the given number.";
            }

            if ( number == 1)
            {
                return "Prime factor of 1 is : 1";
            }

            int inputNumber = number;
            int currentFactor = 2;
            string output = "";

            while (number > 1)
            {
                if (number % currentFactor == 0)
                {
                    output += currentFactor + " x ";
                    number /= currentFactor;
                }
                else
                {
                    currentFactor++;
                }
            }

            return "Prime factors of "+ inputNumber + " are : " + output.Remove(output.Length - 2);

        }
    }
}