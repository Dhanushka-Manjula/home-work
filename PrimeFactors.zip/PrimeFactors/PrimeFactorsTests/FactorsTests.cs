﻿using Microsoft.VisualStudio.TestPlatform.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PrimeFactors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeFactors.Tests
{
    [TestClass()]
    public class FactorsTests
    {
        [TestMethod]
        public void InputNumberIsOne()
        {
            string expected = "Prime factor of 1 is : 1";
            string actual = new Factors().PrimeFactors(1);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void NegativeNumbers()
        {
            string expected = "Can not find the Prime factors for the given number.";
            string actual = new Factors().PrimeFactors(-10);
            Assert.AreEqual(expected, actual);
        }


        [TestMethod]
        public void PositiveNumbers()
        {
            string expected = "Prime factors of 50 are : 2 x 5 x 5 ";
            string actual = new Factors().PrimeFactors(50);
            Assert.AreEqual(expected, actual);
        }
    }
}