﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Wolf : Animal
    {
        int speed;

        public int age { get; set; }
        public string species { get; set; }

        public Wolf()
        {
            this.species = "Wolf";
        }

        public string GetDescription()
        {
            return (this.age + "-year-old " + this.species + " that runs " + this.speed + " km\\h").ToLower();
        }

        public void RequestUniqueCharacteristic()
        {
            Console.Write("How fast can it run (in km\\h)? ");
            this.speed = Int32.Parse(Console.ReadLine());
        }
    }
}
