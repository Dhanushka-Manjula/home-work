﻿using System.Collections;

namespace Zoo
{
    internal class Program
    {
        static void Main(string[] args)
        {

           int cage = 1;
           List<Animal> animals = new List<Animal>();

            while (cage <= 3)
            {
                Console.WriteLine("Cage {0}", cage);
                Console.Write("What is the animal's species? ");
                string species = Console.ReadLine();

                Animal animal = null;
                
                if("Bear".Equals(species, StringComparison.OrdinalIgnoreCase)) {
                    animal = new Bear();
                }
                else if ("Lion".Equals(species, StringComparison.OrdinalIgnoreCase)) {
                    animal = new Lion();
                }
                else if ("Wolf".Equals(species, StringComparison.OrdinalIgnoreCase)) {
                    animal = new Wolf();
                } else {
                    Console.WriteLine("Invalid species. Enter again.");
                    continue;
                }

                try
                {
                    if (animal != null)
                    {
                        Console.Write("How old is it? ");
                        animal.age = Int32.Parse(Console.ReadLine());
                        animal.RequestUniqueCharacteristic();
                        animals.Add(animal);

                        cage++;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("FormatException: invalid input type");
                }          
            }


            // display the Animals
            cage = 1;
            foreach (Animal animal in animals)
            {
                Console.WriteLine("Cage {0} contains a {1}.", cage, animal.GetDescription());
                cage++;
            }
        }
    }
}