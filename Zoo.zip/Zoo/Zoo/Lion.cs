﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Lion : Animal
    {
        string maneColour;
        public int age { get; set; }
        public string species { get; set; }

        public Lion()
        {
            this.species = "Lion";
        }


        public string GetDescription()
        {
            return (this.age + "-year-old " + this.species + " with a " + this.maneColour + " mane").ToLower();
        }

        public void RequestUniqueCharacteristic()
        {
            Console.Write("What colour is its mane? ");
            this.maneColour = Console.ReadLine();
        }

    }
}
