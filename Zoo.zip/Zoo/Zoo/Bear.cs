﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Bear : Animal
    {
        bool isGrizzly;

        public int age { get; set; }
        public string species { get; set; }

        public Bear()
        {
            this.species = "Bear";
        }

        public string GetDescription()
        {
            return (this.age + "-year-old" + (isGrizzly ? " grizzly " : " non-grizzly ") + this.species).ToLower();
        }

        public void RequestUniqueCharacteristic()
        {
            Console.Write("Is it a grizzly bear (true/false) ? ");
            string input = Console.ReadLine();

            this.isGrizzly = "Yes".Equals(input, StringComparison.OrdinalIgnoreCase);
        }
    }
}
